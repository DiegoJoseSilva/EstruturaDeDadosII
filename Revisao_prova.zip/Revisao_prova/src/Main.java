import java.util.Arrays;

public class Main {
    public static void questao1(int[] array){
        int n=array.length;
        boolean houve_troca = false;

        for(int i= 0; i<n; i++){
                houve_troca = false;
                for(int j=0; j<n-1; j++){
                    if(array[j]>array[j+1]){
                        houve_troca = true;
                        break;
                    }
                }
                if(houve_troca){
                    break;
                }
        }
        if(houve_troca){
            System.out.println("Vetor não está em ordem crescente!");
        }else{
            System.out.println("O vetor está em ordem crescente!");
        }
    }

    public static void questao2(int[] array, int x){
        int n = array.length;
        int[] arr = new int[n+1];

        int i = 0, j=0;

        while(i<n && array[i]<x){
            arr[i++]=array[j++];
        }

        arr[j++]= x;

        while(i<n){
            arr[j++]=array[i++];
        }

        System.out.println(Arrays.toString(arr));
    }


    public static void questao3(int[] arr) {
        insertionSortRec(arr, arr.length);
        System.out.println(Arrays.toString(arr));
    }

    public static void insertionSortRec(int[] arr, int n) {
        // Caso base
        if (n <= 1) {
            return;
        }

        // 🔁 Aqui está o segredo (recursão)
        insertionSortRec(arr, n - 1);

        // Insere o último elemento na posição correta
        int ultimo = arr[n - 1];
        int j = n - 2;

        while (j >= 0 && arr[j] > ultimo) {
            arr[j + 1] = arr[j];
            j--;
        }

        arr[j + 1] = ultimo;
    }


    public static void selectionSortRec(int[] arr, int index) {
        int n = arr.length;

        // Caso base
        if (index >= n - 1) {
            return;
        }

        // Encontra o índice do menor elemento
        int minIndex = index;
        for (int i = index + 1; i < n; i++) {
            if (arr[i] < arr[minIndex]) {
                minIndex = i;
            }
        }

        // Troca o menor com a posição atual
        int temp = arr[minIndex];
        arr[minIndex] = arr[index];
        arr[index] = temp;

        // 🔁 Chamada recursiva para o restante
        selectionSortRec(arr, index + 1);
    }

    public static void questao5(int[] arr){
        int n = arr.length;

        for(int i =0; i<n-1; i++){
            int maiorIndice = i;

            for(int j = i+1; j<n; j++){
                if (arr[maiorIndice]<arr[j]) {
                    maiorIndice = j;
                }
                if (maiorIndice != i) {
                    int temp = arr[i];
                    arr[i]=arr[maiorIndice];
                    arr[maiorIndice]= temp;
                }
            }
        }
        System.out.println(Arrays.toString(arr));
    }

    public static void main(String[] args) {
       int [] array = {3,1,10,4,5};
       //questao1(array);
       //questao2(array, 2);
       //selectionSortRec(array, 0);
       //System.out.println(Arrays.toString(array));
       questao5(array);

    }
}