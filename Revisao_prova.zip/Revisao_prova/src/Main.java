import java.util.Arrays;

public class Main {
    public static void questao1(int[] array){
        int n=array.length;
        boolean houve_troca = false;

        for(int i= 0; i<n; i++){
                houve_troca = false;
                for(int j=0; j<n-1; j++){
                    if(array[j]>array[j+1]){
                        houve_troca = true;
                        break;
                    }
                }
                if(houve_troca){
                    break;
                }
        }
        if(houve_troca){
            System.out.println("Vetor não está em ordem crescente!");
        }else{
            System.out.println("O vetor está em ordem crescente!");
        }
    }

    public static void questao2(int[] array, int x){
        int n = array.length;
        int[] arr = new int[n+1];

        int i = 0, j=0;

        while(i<n && array[i]<x){
            arr[i++]=array[j++];
        }

        arr[j++]= x;

        while(i<n){
            arr[j++]=array[i++];
        }

        System.out.println(Arrays.toString(arr));
    }



    public static void main(String[] args) {
       int [] array = {3,1,10,4,5};
       //questao1(array);
       //questao2(array, 2);


    }
}