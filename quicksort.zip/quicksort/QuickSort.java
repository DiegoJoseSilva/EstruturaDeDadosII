package trainningselectionsort.quicksort;


public class QuickSort {
    
    public static int  partition(int array[], int left, int right){
        int pivot = left;
        int i = left -1;
        
        for(int j=left; j<right-1; j++){
            if(array[j]<= pivot){
                i = i+1;
                int temp = array[i];
                array[i]=array[j];
                array[j]=temp;
            } 
        }
        
        int temp = array[i+1];
        array[i+1] = array[right];
        array[right]= temp;
        return i + 1;
    }
    
    
    public static void quickSort(int array[],int left, int right){
        if(left>right){
            int pivot_index = partition(array, left, right);
            quickSort(array, left, pivot_index-1);
            quickSort(array, right, pivot_index+1);
        }
    }
    
    public static void main(String[] args) {
        
        
       
    }
}
