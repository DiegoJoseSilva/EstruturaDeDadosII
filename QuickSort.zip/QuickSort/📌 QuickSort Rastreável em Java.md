# **📌 QuickSort Rastreável em Java**

## **📖 Descrição do Projeto**

Este projeto implementa o algoritmo **Quick Sort** em Java, utilizando o paradigma de **Dividir e Conquistar**, com foco educacional.

O diferencial deste trabalho é a **rastreabilidade**, ou seja, o programa exibe no console:

* O vetor antes da ordenação  
* O pivô escolhido  
* Cada comparação realizada  
* Cada troca executada  
* As chamadas recursivas  
* O vetor após cada partição  
* O vetor final ordenado

O objetivo é facilitar a compreensão do funcionamento interno do algoritmo.

---

## **🧠 Sobre o Algoritmo Quick Sort**

O Quick Sort funciona da seguinte forma:

1. Escolhe um elemento como **pivô**  
2. Divide o vetor em duas partes:  
   * Elementos menores ou iguais ao pivô  
   * Elementos maiores que o pivô  
3. Aplica o mesmo processo recursivamente nas sublistas  
4. Repete até que o vetor esteja totalmente ordenado

Esse processo segue o modelo de **Dividir para Conquistar**.

---

## **⚙️ Estratégia Utilizada**

Neste projeto foi utilizada a estratégia:

✔ **Pivô à direita**

Conforme o pseudocódigo da função `Partition`, o último elemento do vetor é escolhido como pivô.

---

## **📂 Estrutura do Projeto (Maven)**

QuickSortRastreavel/  
│  
├── src/  
│   └── main/  
│       └── java/  
│           └── com/mycompany/quicksortrastreavel/  
│               └── QuickSortRastreavel.java  
│  
├── pom.xml  
└── README.md  
---

## **▶️ Como Executar o Projeto**

### **🔹 Pré-requisitos**

* Java JDK 23 (ou superior)  
* Apache Maven  
* NetBeans (opcional)

---

### **🔹 Execução pelo NetBeans**

1. Abra o projeto  
2. Clique em **Run**  
3. O resultado aparecerá no console

---

### **🔹 Execução pelo Terminal**

Dentro da pasta do projeto:

#### **Compilar:**

mvn clean compile

#### **Executar:**

mvn exec:java  
---

## **📊 Exemplo de Saída**

O programa imprime:

* Vetor original  
* Pivô selecionado  
* Comparações  
* Trocas realizadas  
* Vetor ordenado

Exemplo:

Vetor original:  
\[10, 7, 8, 9, 1, 5\]

Pivô escolhido: 5  
Comparando 10 com pivô 5  
Troca realizada:  
...

Vetor ordenado:  
\[1, 5, 7, 8, 9, 10\]  
---

## **🎯 Objetivo Acadêmico**

Este projeto tem como finalidade:

* Compreender o funcionamento do Quick Sort  
* Entender o conceito de recursividade  
* Visualizar o processo de partição  
* Aplicar boas práticas de organização de projeto  
* Utilizar controle de versão com GitHub

---

## **👨‍💻 Autor**

Diego José da Silva  
Disciplina: Estruturas de Dados II  
Ano: 2026

